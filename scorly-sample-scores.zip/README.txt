Sample scores for testing Scorly
================================

Fifteen pieces of sheet music to import into Scorly, so that you have something
to read, mark up and put into a setlist without hunting for your own files
first. Nothing here is precious - import all of it, delete what you do not
want, and do not worry about spoiling anything.

Twelve are PDFs. Three are JPEG images of a single page, which go in through the
same Import button and are there so that the photograph route gets tried too.

Two ways in are worth trying, because they are different code:

  1. Import -> pick one or several PDFs at once.
  2. Import -> pick the three .jpg files, which is what importing photographs
     of a page looks like.

A few of these were chosen for a reason:

  - Good King Wenceslas, Greensleeves (SATB), Cavallini and Abt are single
    pages. A one-page score should still open, and should not offer to turn.
  - Beethoven's Symphony No. 7 is 55 pages. It is the one to open if you want
    to know whether page turns stay quick in something long.
  - Bach's Toccata and Fugue is 11 pages of dense organ writing, which is the
    hardest thing here to read at a stand.

What is in it
-------------

  1 p    Abt - Vocalise No 1 (voice and piano)
  8 pp   Albeniz - Rumores de la Caleta (piano)
  1 p    Anonymous - Good King Wenceslas (voice)
  3 pp   Anonymous - Greensleeves to a Ground (violin)
  2 pp   Bach - Air on the G String (flute and guitar)
  2 pp   Bach - Prelude in D minor BWV 999 (guitar)
 11 pp   Bach - Toccata and Fugue in D minor BWV 565 (organ)
  3 pp   Beethoven - Prelude WoO 55 (piano)
 55 pp   Beethoven - Symphony No 7, 2nd movement (orchestra)
  1 p    Cavallini - Thirty Caprices No 1 (clarinet)
  5 pp   Telemann - Duett TWV 40-107 (two recorders)
  1 p    Traditional - Greensleeves (SATB)

  images:
  1 p    Carcassi - Two Minor Preludes (guitar)
  1 p    Horetzky - Russian Air (guitar)
  1 p    Horetzky - The Last Rose of Summer (guitar)

Where it comes from, and why you may keep it
--------------------------------------------

Every file here is from the Mutopia Project (www.mutopiaproject.org) and every
one of them is Public Domain - the music because of its age, and the engraving
because the person who typeset it placed it in the public domain. Each page says
so in its own footer, which you can check without taking anyone's word for it.

That mattered in choosing them: a modern edition of an old piece can carry
rights of its own in the typesetting, so a page out of your own shelf is not
automatically free to pass around. These are.

The JPEGs were made from three more Mutopia PDFs by rendering the page at
1555x2200; they are otherwise the same material.

Found something wrong?
----------------------

support@scorlyapp.com - including "it looked ugly". A confusing screen is a
finding, not a complaint.
